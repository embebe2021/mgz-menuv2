import '@szhsin/react-menu/dist/index.css';
import '@szhsin/react-menu/dist/transitions/slide.css';
import _ from 'lodash';
import { nanoid } from 'nanoid';
import demoData from './demoData/demo2';
import Menu from './components/Menu';
import MenuItem from './components/MenuItem';

export type MenuItem = {
    mainItem: string[];
};

export type MenuItemDataType = Record<
    string,
    {
        id: string;
        label: string;
        icon?: string;
        parent?: string;
        childIds?: string[];
    }
>;

export type MainMenuType = MenuItem & MenuItemDataType;

export const App = (): JSX.Element => {
    const mainItemList = demoData.mainItem;
    return (
        <Menu direction="vertical" dataHook="main-menu">
            {_.map(mainItemList, (itemId) => (
                <MenuItem
                    key={nanoid()}
                    id={itemId}
                    sourceData={demoData}
                    direction="vertical"
                    onClick={(val) => console.log(val)}
                    subMenuAlign="start"
                    subMenuDirection="right"
                />
            ))}
        </Menu>
    );
};
