function makeTestHook(dataHook: string | undefined): { [key: string]: string } {
    return { ...(dataHook && { 'data-hook': dataHook }) };
}
export default makeTestHook;
