import * as iconLibs from '@wix/wix-ui-icons-common';

function getIcon(icon: string) {
    const newString = icon.charAt(0).toUpperCase() + icon.slice(1);
    const Icon = iconLibs[newString] as React.FC;
    return <Icon />;
}

export default getIcon;
