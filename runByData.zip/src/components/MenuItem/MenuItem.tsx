import { useRef, useState } from 'react';
import _ from 'lodash';
import { Text } from 'wix-style-react';
import type { MenuItemDataType } from '../../App';
import { st, classes } from './MenuItem.st.css';
import SubMenu from '../SubMenu/SubMenu';
import makeTestHook from '../../ultis/makeTestHook';
import getIcon from '../../ultis/getIcon';

type MenuItemProps = {
    id: string;
    sourceData: MenuItemDataType;
    className?: string;
    style?: React.CSSProperties;
    direction?: 'horizontal' | 'vertical';
    dataHook?: string;
    subMenuAlign?: 'start' | 'center' | 'end';
    subMenuDirection?: 'left' | 'right' | 'top' | 'bottom';
    subMenuOffsetX?: number;
    subMenuOffsetY?: number;
    onClick: (val: object) => void;
};

const MenuItem = ({
    id,
    sourceData,
    className,
    style,
    direction,
    dataHook,
    subMenuAlign,
    subMenuDirection,
    subMenuOffsetX,
    subMenuOffsetY,
    onClick,
}: MenuItemProps): JSX.Element => {
    const itemRef = useRef<HTMLDivElement>(null);

    const [isOpen, setOpen] = useState<boolean>(false);

    const menuItemData = sourceData[id];

    const { label, icon } = menuItemData;

    const hasChild = 'childIds' in menuItemData && _.size(menuItemData.childIds) > 0;

    const handleOpenChild = (): void => {
        hasChild && setOpen(true);
    };

    const handleClick = (): void => {
        _.isFunction(onClick) && onClick({ menuItemData, itemRef });
    };

    return (
        <li className={st(classes.root, className)} style={style} {...makeTestHook(dataHook)}>
            {/* Main Item */}
            <div
                ref={itemRef}
                className={st(classes.content, {
                    hasChild,
                    isHorizontal: direction === 'horizontal',
                })}
                onPointerEnter={handleOpenChild}
                onClick={handleClick}
            >
                {icon && getIcon(icon)}
                <Text>{label}</Text>
            </div>

            {/* Has Submenu */}
            {hasChild && isOpen && (
                <SubMenu
                    state={isOpen ? 'open' : 'closed'}
                    anchorRef={itemRef}
                    setOpen={setOpen}
                    align={subMenuAlign}
                    direction={subMenuDirection}
                    offsetX={subMenuOffsetX}
                    offsetY={subMenuOffsetY}
                    subItemList={menuItemData.childIds as string[]}
                    sourceData={sourceData}
                />
            )}
        </li>
    );
};

export default MenuItem;
