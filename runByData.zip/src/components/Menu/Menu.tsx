import makeTestHook from '../../ultis/makeTestHook';
import { st, classes } from './Menu.st.css';

type MenuProps = {
    direction?: 'horizontal' | 'vertical';
    children?: React.ReactNode;
    dataHook?: string;
    className?: string;
    style?: React.CSSProperties;
};

const Menu = ({ direction = 'vertical', children, dataHook, className, style }: MenuProps) => {
    return (
        <ul
            {...makeTestHook(dataHook)}
            className={st(
                classes.root,
                {
                    direction: direction,
                },
                className
            )}
            style={style}
        >
            {children ? children : null}
        </ul>
    );
};

export default Menu;
