import React from 'react';
import { ControlledMenu } from '@szhsin/react-menu';
import { nanoid } from 'nanoid';
import _ from 'lodash';
import { st, classes } from './SubMenu.st.css';
import type { MenuItemDataType } from '../../App';
import SubMenuItem from '../SubMenuItem';

type SubMenuProps = {
    state: 'open' | 'closed';
    subItemList: string[];
    sourceData: MenuItemDataType;
    anchorRef?: React.RefObject<Element>;
    className?: string;
    offsetX?: number;
    offsetY?: number;
    align?: 'start' | 'center' | 'end';
    direction?: 'left' | 'right' | 'top' | 'bottom';
    style?: React.CSSProperties;
    setOpen?: (val: boolean) => void;
    onMount?: (...arg: any) => void;
    onUnMount?: (...arg: any) => void;
};

class SubMenu extends React.Component<SubMenuProps> {
    constructor(props: SubMenuProps) {
        super(props);
    }

    componentDidMount(): void {
        const { onMount } = this.props;
        _.isFunction(onMount) && onMount();
    }

    componentWillUnmount(): void {
        const { onUnMount } = this.props;
        _.isFunction(onUnMount) && onUnMount();
    }

    closeSubMenu = (): void => {
        const { setOpen } = this.props;
        _.isFunction(setOpen) && setOpen(false);
    };

    render(): React.ReactNode {
        const {
            state = 'open',
            subItemList,
            sourceData,
            anchorRef,
            className,
            style,
            align,
            direction,
            offsetX,
            offsetY,
        } = this.props;

        const { closeSubMenu } = this;

        return (
            <ControlledMenu
                state={state}
                anchorRef={anchorRef}
                onPointerLeave={closeSubMenu}
                onClose={closeSubMenu}
                menuClassName={st(classes.root, className)}
                menuStyle={style}
                offsetX={offsetX}
                offsetY={offsetY}
                align={align}
                direction={direction}
                viewScroll="close"
                overflow="auto"
            >
                {_.map(subItemList, (id) => {
                    return (
                        <SubMenuItem
                            key={nanoid()}
                            id={id}
                            sourceData={sourceData}
                            subItem={{
                                onClick: (value: string) => console.log(value),
                                value: 'hello',
                            }}
                        />
                    );
                })}
            </ControlledMenu>
        );
    }
}

export default SubMenu;
