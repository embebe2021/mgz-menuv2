import React from 'react';
import { MenuItem as LibMenuItem, SubMenu as LibSubMenu } from '@szhsin/react-menu';
import { Text } from 'wix-style-react';
import _ from 'lodash';
import { nanoid } from 'nanoid';
import { st, classes } from './SubMenuItem.st.css';
import type { MenuItemDataType } from '../../App';
import getIcon from '../../ultis/getIcon';

type LibSubMenu = {
    menuClassName?: string;
    menuStyle?: React.CSSProperties;
    offsetX?: number;
    offsetY?: number;
};

type LibSubItem = {
    className?: string;
    href?: string;
    onClick?: (value: string) => void;
    value?: any;
    type?: 'checkbox' | 'radio';
};

type SubMenuItemProps = {
    id: string;
    sourceData: MenuItemDataType;
    subMenu?: LibSubMenu;
    subItem?: LibSubItem;
};

const SubMenuItem = ({
    id,
    sourceData,
    subMenu = {},
    subItem = {},
}: SubMenuItemProps): JSX.Element => {
    const subItemData = sourceData[id];

    const isSubMenu = 'childIds' in subItemData && _.size(subItemData.childIds) > 0;

    const { label, icon, childIds } = subItemData;

    const { onClick, className, ...itemRest } = subItem!;
    const { menuClassName, ...subMenuRest } = subMenu!;

    const handleOnClick = (): void => {
        _.isFunction(onClick) && onClick({ subItemData });
    };

    return (
        <React.Fragment>
            {isSubMenu ? (
                <LibSubMenu
                    label={
                        <div className={classes.wrapper} onClick={handleOnClick}>
                            {icon && getIcon(icon)}
                            <Text>{label}</Text>
                        </div>
                    }
                    overflow="auto"
                    menuClassName={st(classes.libSubMenu, menuClassName && '')}
                    {...subMenuRest}
                >
                    {_.map(childIds, (id) => (
                        <SubMenuItem
                            key={nanoid()}
                            id={id}
                            sourceData={sourceData}
                            subMenu={subMenu}
                            subItem={subItem}
                        />
                    ))}
                </LibSubMenu>
            ) : (
                <LibMenuItem
                    className={st(classes.root, className && '')}
                    onClick={handleOnClick}
                    {...itemRest}
                >
                    {icon && getIcon(icon)}
                    <Text>{label}</Text>
                </LibMenuItem>
            )}
        </React.Fragment>
    );
};

export default SubMenuItem;
